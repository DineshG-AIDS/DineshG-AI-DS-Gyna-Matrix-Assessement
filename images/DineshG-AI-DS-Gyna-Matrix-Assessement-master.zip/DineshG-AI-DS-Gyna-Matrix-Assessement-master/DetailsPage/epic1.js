const vv = document.getElementById("show1");
vv.addEventListener("click", () => {
  window.location.href = "http://www.w3schools.com";
});
